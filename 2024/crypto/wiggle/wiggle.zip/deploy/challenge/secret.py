FLAG = b"SparkCTF{W_Y3mchI_w1_Yji_7arAtatataan}"
