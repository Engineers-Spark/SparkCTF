#!/bin/bash
docker rm -f wiggle
docker compose up -d --build